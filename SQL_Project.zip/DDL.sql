CREATE DATABASE INVENTORYSystems;
USE INVENTORYSystems;
Create Table Customers(
customer_id int PRIMARY KEY,
cname varchar(244),
caddress varchar(255)
);
Create Table Employees(
employee_id int PRIMARY KEY,
ename varchar(150),
eemail varchar(305),
etitle varchar(215),
customer_id int,
FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
Create Table Suppliers(
supplier_id int PRIMARY KEY,
sname varchar(240),
scountry varchar(245)
);
Create Table Products(
product_id varchar(265) PRIMARY KEY,
pname varchar(287),
pdescription varchar(1000),
pprice int
);
Create Table Orders(
order_id int PRIMARY KEY,
ostatus varchar(315),
odate int,
product_id varchar(225),
FOREIGN KEY (product_id) REFERENCES Products(product_id)
);
Create Table OrderDetails(
ordernumber int PRIMARY KEY, 
productcode varchar(255),
order_id int,
FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);
Create Table Sales(
sale_id int PRIMARY KEY,
amount int,
sdate int,
supplier_id int,
FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
);
Create Table Stocks(
stockquantity varchar(200),
product_id varchar(205),
FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

