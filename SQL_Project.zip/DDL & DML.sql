CREATE DATABASE INVENTORYSystems;
USE INVENTORYSystems;
Create Table Customers(
customer_id int PRIMARY KEY,
cname varchar(244),
caddress varchar(255)
);
Create Table Employees(
employee_id int PRIMARY KEY,
ename varchar(150),
eemail varchar(305),
etitle varchar(215),
customer_id int,
FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
Create Table Suppliers(
supplier_id int PRIMARY KEY,
sname varchar(240),
scountry varchar(245)
);
Create Table Products(
product_id varchar(265) PRIMARY KEY,
pname varchar(287),
pdescription varchar(1000),
pprice int
);
Create Table Orders(
order_id int PRIMARY KEY,
ostatus varchar(315),
odate int,
product_id varchar(225),
FOREIGN KEY (product_id) REFERENCES Products(product_id)
);
Create Table OrderDetails(
ordernumber int PRIMARY KEY, 
productcode varchar(255),
order_id int,
FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);
Create Table Sales(
sale_id int PRIMARY KEY,
amount int,
sdate int,
supplier_id int,
FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
);
Create Table Stocks(
stockquantity varchar(200),
product_id varchar(205),
FOREIGN KEY (product_id) REFERENCES Products(product_id)
);
-- Inserting rows into Customers table
INSERT INTO Customers(customer_id,cname,caddress) VALUES
(103,'Atelier graphique', 'rue Royale'),
(112,'Signal Gift Stores','8489 Strong St.'),
(114,'Australian Collectors','636 St Kilda Road''Level 3'),
(119,'La Rochelle Gifts','67, rue des Cinquante Otages'),
(121,'Baane Mini Imports','Erling Skakkes gate 78'),
(124,'Mini Gifts Distributors Ltd.','5677 Strong St.'),
(125,'Havel & Zbyszek Co','ul. Filtrowa 68'),
(128,'Blauer See Auto, Co.','Lyonerstr. 34'),
(129,'Mini Wheels Co.','5557 North Pendale Street'),
(131,'Land of Toys Inc.','897 Long Airport Avenue');

-- Inserting rows into Employees table
INSERT INTO Employees(employee_id,ename,eemail,etitle,customer_id) VALUES
(1002,'Murphy','dmurphy@classicmodelcars.com','President',121),
(1056,'Patterson','mpatterso@classicmodelcars.com','VP Sales',119),
(1076,'Firrelli','jfirrelli@classicmodelcars.com','VP Marketing',103),
(1088,'Patterson','wpatterson@classicmodelcars.com','Sales Manager (APAC)',112),
(1102,'Bondur','gbondur@classicmodelcars.com','Sale Manager (EMEA)',114),
(1143,'Bow','abow@classicmodelcars.com','Sales Manager (NA)',125),
(1165,'Jennings','ljennings@classicmodelcars.com','Sales Rep',131),
(1166,'Thompson','lthompson@classicmodelcars.com','Sales Rep',129),
(1188,'Firrelli','jfirrelli@classicmodelcars.com','Sales Rep',124),
(1216,'Patterson','spatterson@classicmodelcars.com','Sales Rep',128);

-- Inserting rows into OrderDetails table
INSERT INTO OrderDetails(ordernumber, productcode) VALUES
(10110,'S18_1749'),
(10100,'S18_2248'),
(10140,'S18_4409'),
(10130,'S24_3969'),
(10101,'S18_2325'),
(10102,'S18_2795'),
(10103,'S24_1937'),
(10104,'S24_2022'),
(10105,'S18_1342'),
(10106,'S18_1367');

-- Inserting rows into Orders table
INSERT INTO Orders(order_id,odate,ostatus) VALUES
(10100,'2003-01-06','Shipped'),
(10101,'2003-01-09','Shipped'),
(10102,'2003-01-10','Shipped'),
(10103,'2003-01-29','Shipped'),
(10104,'2003-01-31','Shipped'),
(10105,'2003-02-11','Shipped'),
(10106,'2003-02-17','Shipped'),
(10107,'2003-02-24','Shipped'),
(10108,'2003-03-03','Shipped'),
(10109,'2003-03-10','Shipped');

-- Inserting rows into Products table
INSERT INTO Products(product_id,pname,pdescription,pprice) VALUES
('S10_1678','1969 Harley Davidson Ultimate Chopper','This replica features working kickstand, front suspension, gear-shift lever, footbrake lever, drive chain, wheels and steering. All parts are particularly delicate due to their precise scale and require special care and attention.',7933),
('S10_1949','1952 Alpine Renault 1300','Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.',7305),
('S10_2016','1996 Moto Guzzi 1100i','Official Moto Guzzi logos and insignias, saddle bags located on side of motorcycle, detailed engine, working steering, working suspension, two leather seats, luggage rack, dual exhaust pipes, small saddle bag located on handle bars, two-tone paint with chrome accents, superior die-cast detail , rotating wheels , working kick stand, diecast metal with plastic parts and baked enamel finish.',6625),
('S10_4698','2003 Harley-Davidson Eagle Drag Bike','Model features, official Harley Davidson logos and insignias, detachable rear wheelie bar, heavy diecast metal with resin parts, authentic multi-color tampo-printed graphics, separate engine drive belts, free-turning front fork, rotating tires and rear racing slick, certificate of authenticity, detailed engine, display stand\r\n, precision diecast replica, baked enamel finish, 1:10 scale model, removable fender, seat and tank cover piece for displaying the superior detail of the v-twin engine',5582),
('S10_4757','1972 Alfa Romeo GTA','Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.',3252),
('S10_4962','1962 LanciaA Delta 16V','Features include: Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.',6791),
('S12_1099','1968 Ford Mustang','Hood, doors and trunk all open to reveal highly detailed interior features. Steering wheel actually turns the front wheels. Color dark green.',68),
('S12_1108','2001 Ferrari Enzo','Turnable front wheels; steering function; detailed interior; detailed engine; opening hood; opening trunk; opening doors; and detailed chassis.',3619),
('S12_1666','1958 Setra Bus','Model features 30 windows, skylights & glare resistant glass, working steering system, original logos',1579),
('S12_2823','2002 Suzuki XREO','Official logos and insignias,skylights & glare resistant glass, working steering system, original logos',1579);

-- Inserting rows into stocks table
INSERT INTO Stocks(stockquantity) VALUES
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(1),
(2),
(9);

-- Inserting rows into Suppliers table
INSERT INTO Suppliers(supplier_id,sname,scountry) VALUES
(89	,'White Clover Markets','USA'),
(90,'Wilman Kala','Finland'),
(91,'Wolski','Poland'),
(92,'Cardinal','Stavanger'),
(93,'Bon app','Argentina'),
(94,'Around the Horn','UK'),
(95,'Maison','Germany'),
(96,'Morgenstern','Canada'),
(97,'Ottilies','Japan'),
(98,'Magazzini','China');

-- Inserting rows into Sales table
INSERT INTO Sales(sale_id,amount,sdate) VALUES
(11101,100,'2003-01-09'),
(11102,500,'2003-01-10'),
(11103,60,'2003-01-29'),
(11104,75,'2003-01-31'),
(11105,80,'2003-02-11'),
(11106,90,'2003-02-17'),
(11107,75,'2003-02-24'),
(11108,150,'2003-03-03'),
(11109,200,'2003-03-10'),
(11110,350,'2003-01-18');
